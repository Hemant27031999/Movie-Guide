package com.example.movieguide;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatTextView;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import static com.example.movieguide.MainActivity.mDate;
import static com.example.movieguide.MainActivity.mDescp;
import static com.example.movieguide.MainActivity.mImageUrl;
import static com.example.movieguide.MainActivity.mRate;
import static com.example.movieguide.MainActivity.mTitle;

public class film_indi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film_indi);

        Intent intent = getIntent();
        String imageUrl = intent.getStringExtra(mImageUrl);
        String title = intent.getStringExtra(mTitle);
        String release_date = intent.getStringExtra(mDate);
        String rate = intent.getStringExtra(mRate);
        String descp = intent.getStringExtra(mDescp);

        ImageView imageView = findViewById(R.id.mainimg);
        AppCompatTextView textViewtitle = findViewById(R.id.title);
        TextView textViewdate = findViewById(R.id.date);
        TextView textViewrate = findViewById(R.id.rate);
        TextView textViewdescp = findViewById(R.id.descp);

        Picasso.with(this).load(imageUrl).into(imageView);
        textViewtitle.setText(title);
        textViewdate.setText(release_date);
        textViewrate.setText(rate);
        textViewdescp.setText(descp);
    }
}
